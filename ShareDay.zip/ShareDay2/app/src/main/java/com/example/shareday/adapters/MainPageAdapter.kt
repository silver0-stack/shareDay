package com.example.shareday.adapters

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.example.shareday.fragments.*


//메인페이지에서 하단네비게이션바를 눌렀을 때, 뷰페이저에 나타나는 fragment를 연결하기 위한 Adapter

class MainPageAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {
    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> ChatFragment() as Fragment
            1 -> HelpMeFragment() as Fragment
            2 -> MapFragment() as Fragment
            3 -> HelpYouFragment() as Fragment
            else -> MyPageFragment() as Fragment
        }
    }

    override fun getCount() = 5
}