package com.example.shareday

import android.Manifest
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.viewpager.widget.ViewPager
import com.example.shareday.adapters.MainPageAdapter
import com.google.android.material.chip.Chip


class MainActivity : AppCompatActivity() {

    private lateinit var bottomNav:Chip //하단메뉴바
    lateinit var viewContainer: ViewPager //하단메뉴바로 바뀌는 화면


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
            1
        ) //사진 접근 권한


        bottomNav = findViewById(R.id.bottom_mainNav)
        viewContainer = findViewById(R.id.view_container)

        viewContainer.adapter = MainPageAdapter(supportFragmentManager)
        viewContainer.offscreenPageLimit = 5 //뷰 계층 구조에 보관된 페이지, view/fragment 수 제어

        bottomNav.setOnNavigationItemSelectedListener {it->
            when (it.itemId) {
                // itemId에 따라 viewPager 바뀜
                R.id.menu_chat -> viewContainer.currentItem = 0
                R.id.menu_helpMe -> viewContainer.currentItem = 1
                R.id.menu_map -> viewContainer.currentItem = 2
                R.id.menu_helpYou -> viewContainer.currentItem = 3
                R.id.menu_myPage -> viewContainer.currentItem = 4
            }
        }
        viewContainer.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrollStateChanged(state: Int) {}

            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {

            }

            override fun onPageSelected(position: Int) {
                // 네비게이션 메뉴 아이템 체크상태

            }
        })


    }

}
