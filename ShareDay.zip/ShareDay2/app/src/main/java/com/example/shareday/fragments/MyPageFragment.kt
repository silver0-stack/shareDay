package com.example.shareday.fragments

class MyPageFragment {
}