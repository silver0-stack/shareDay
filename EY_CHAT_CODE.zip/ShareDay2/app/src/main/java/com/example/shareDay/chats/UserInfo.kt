package com.example.shareDay.chats

import android.widget.ImageView

class UserInfo(var name: String?,  var profile: String? , var about: String?) {
}